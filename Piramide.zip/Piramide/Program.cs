﻿int numero, linealActual, espacio, asterisco;
Console.Write("Insert number: ");
numero = Convert.ToInt32(Console.ReadLine());
for(linealActual = 1; linealActual <= numero; linealActual++)
{
    for(espacio = 0; espacio < numero - linealActual; espacio ++)
    {
        Console.Write(" ");
    }
    for(asterisco = 0; asterisco < (linealActual * 2) - 1; asterisco++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}
Console.ReadKey();